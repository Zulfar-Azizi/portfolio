# Zulfar Azizi — Creative Portfolio Portfolio

A responsive static portfolio built with HTML, CSS, JavaScript, and original SVG concept illustrations. It is designed to be easy to edit and publish using GitHub Pages.

## Files
- `index.html` — page content and sections
- `style.css` — layout, typography, colors, responsive styling
- `script.js` — mobile navigation and current year
- `assets/` — SVG portfolio concept illustrations

## Preview locally
Open `index.html` in a browser. For best results, use a local static server or the VS Code Live Server extension.

## Publish with GitHub Pages
1. Download and unzip this project.
2. Upload `index.html`, `style.css`, `script.js`, and the entire `assets` folder into the root of your GitHub repository.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site. The public URL will be shown in the Pages settings.

## Before publishing
- Check every biography, role, and credential detail for accuracy.
- The three project visuals are concept studies made for this portfolio layout, not representations of existing client work or personal sketchbook pieces. Replace them with your own original artwork when available.
- Add the exact TESOL/DEL issuer, date, and certificate link if you want those details public.
- An email address is not included because none was supplied.

Personalized updates: added Zulfar’s portrait and contact email (zulfar.azizi.2003@gmail.com). All sections, including the final contact/footer area, are retained.
